import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PlayerCar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PlayerCar extends Actor
{
    private int defaultSpeed = 2;
    public int totalSpeedModifier = 0;
    
    public void SpeedBoost(int boost){
        totalSpeedModifier = totalSpeedModifier + boost;
        sleepFor(2000);
    }
    
    public void act()
    {
       GreenfootImage img = getImage();
       img.scale(15, 20);
       
       int x = getX();
       int y = getY();

       if (Greenfoot.isKeyDown("w")){
           setRotation(180);
           setLocation(x, y - defaultSpeed);
        }
        if (Greenfoot.isKeyDown("s")){
            setRotation(-180);
            setLocation(x, y + defaultSpeed);
        }
        if(Greenfoot.isKeyDown("a")){
            setRotation(90);
            setLocation(x - defaultSpeed, y);
        }
        if(Greenfoot.isKeyDown("d")){
            setRotation(-90);
            setLocation(x + defaultSpeed, y);
        }
        }
        
       }

