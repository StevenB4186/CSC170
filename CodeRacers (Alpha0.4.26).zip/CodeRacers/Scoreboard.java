import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Scoreboard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Scoreboard extends Actor
{
    private int score = 0;
    GreenfootImage img = getImage();

    public void Scoreboard(){
        this.score = score;
    }
    
    public void setScore(int setting){
        this.score = setting;
        this.score = score;
    }
    
    public void updateImage(){
        GreenfootImage img = getImage();
        setImage(new GreenfootImage("Score: " + score, 15, Color.BLACK, Color.WHITE)); 
    }
    
    public void addScore(int points){
        sleepFor(15);
        this.score = score + points;
        this.score = score;
        setImage(new GreenfootImage("Score: " + score, 15, Color.BLACK, Color.WHITE)); 
    }
    
    public void act()
    {
        // Add your action code here.
    }
}
