import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Timer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Timer extends Actor
{
    private int time = 0;
    
    public void Timer(){
        this.time = time;
    }
    
    public void updateImage(){
        GreenfootImage img = getImage();
        setImage(new GreenfootImage("Time: " + time, 15, Color.BLACK, Color.WHITE)); 
    }
    
    
    public void act()
    {
       sleepFor(60);
       this.time = time + 1;
       this.time = time;
       setImage(new GreenfootImage("Time: " + time, 15, Color.BLACK, Color.WHITE)); 
    }
}
