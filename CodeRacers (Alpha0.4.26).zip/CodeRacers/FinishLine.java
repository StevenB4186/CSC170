import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FinishLine here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FinishLine extends Actor
{
    public void checkHit(){
        if (isTouching(PlayerCar.class)){
            LapCounter laps = (LapCounter) getWorld().getObjects(LapCounter.class).get(0);
            laps.addLap();
            sleepFor(500);
        }
        
    }
   
    public void act()
    {
        GreenfootImage img = getImage();
        img.scale(30, 30);
        checkHit();
    }
}
