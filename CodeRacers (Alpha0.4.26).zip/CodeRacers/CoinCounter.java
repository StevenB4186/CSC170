import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CoinCounter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CoinCounter extends Actor
{
    private int count = 0;
    
    public void CoinCounter(){
        this.count = count;
    }
    
    public void setCount(int setting){
        this.count = setting;
        this.count = count;
    }
    
    public void updateImage(){
        GreenfootImage img = getImage();
        setImage(new GreenfootImage("Coins: " + count, 15, Color.BLACK, Color.WHITE)); 
    }
    
    public void act()
    {
        // Add your action code here.
    }
}
