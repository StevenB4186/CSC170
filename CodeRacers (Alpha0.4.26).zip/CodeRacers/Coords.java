import greenfoot.*;


public class Coords extends Actor
{
    public Coords() {
        GreenfootImage img = new GreenfootImage(10, 10);
        img.setColor(Color.RED);
        img.fillOval(0, 0, 10, 10);
        setImage(img);
        
    }
    
    public String colorName(Color c) {

    int r = c.getRed();
    int g = c.getGreen();
    int b = c.getBlue();

    if (r > 240 && g > 240 && b > 240) return "WHITE";
    if (r < 20 && g < 20 && b < 20) return "BLACK";
    if (r > 200 && g < 80 && b < 80) return "RED";
    if (g > 200 && r < 80 && b < 80) return "GREEN";
    if (b > 200 && r < 80 && g < 80) return "BLUE";
    if (r > 200 && g > 200 && b < 80) return "YELLOW";
    if (Math.abs(r - g) < 20 &&
        Math.abs(g - b) < 20 &&
        r > 80 && r < 200)
        return "GRAY";

    return "UNKNOWN";
}      

    public void act(){
        Color c = getWorld().getBackground().getColorAt(getX(), getY());

        String name = colorName(c);

        getWorld().showText(name, getX(), getY() - 15);

    }
    
}

