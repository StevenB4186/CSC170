import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Coin1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Coin1 extends Actor
{
    private int scoreValue = 100;
    private int count = 0;
    
    public void Coin1(){
        this.scoreValue = scoreValue;
    }

    public void checkHit(){
        if (isTouching(PlayerCar.class)){
          Scoreboard board = (Scoreboard) getWorld().getObjects(Scoreboard.class).get(0);
          board.addScore(scoreValue);
          getWorld().removeObject(this);
        }
    }
    
    public void act()
    {
        GreenfootImage img = getImage();
        img.scale(15, 20);
        checkHit();
    }
}
