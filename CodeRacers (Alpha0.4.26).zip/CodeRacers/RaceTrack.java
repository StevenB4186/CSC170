import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class RaceTrack here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RaceTrack extends World
{

    /**
     * Constructor for objects of class RaceTrack.
     * 
     */
    public RaceTrack()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 600, 1); 
        setBackground("racetrack.png");
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        //data objs
        Scoreboard score = new Scoreboard();
        addObject(score, 550, 25);
        score.updateImage();

        Timer time = new Timer();
        addObject (time, 550, 50);
        time.updateImage();
        
        FinishLine finish = new FinishLine();
        addObject(finish, 308, 550);
        
        LapCounter laps = new LapCounter();
        addObject(laps, 550, 75);
        laps.updateImage();

        //cars (player&npc)
        PlayerCar playerCar = new PlayerCar();
        addObject(playerCar,278,540);
        
        NPCCar nPCCar = new NPCCar();
        addObject(nPCCar,231,540);
        
        NPCCar nPCCar2 = new NPCCar();
        addObject(nPCCar2,250,557);
        
        NPCCar nPCCar3 = new NPCCar();
        addObject(nPCCar3,200,557);
        

        //modifiers
        Coin1 coin = new Coin1();
        addObject(coin, 400, 550);

        
    }
    
}
