import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LapCounter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LapCounter extends Actor
{
    static int laps = 0;
    
    public void LapCounter(){
        this.laps = laps;
    }
    
    public void setLaps(int setting){
        this.laps = setting;
        this.laps = laps;
    }
    
    public void updateImage(){
        GreenfootImage img = getImage();
        setImage(new GreenfootImage("Lap: " + laps, 15, Color.BLACK, Color.WHITE)); 
    }
    
    public void addLap(){
        this.laps = this.laps + 1;
        this.laps = laps;
        setImage(new GreenfootImage("Lap: " + laps, 15, Color.BLACK, Color.WHITE));
    }
    
    public void act()
    {
        // Add your action code here.
    }
}
