import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class NPCCar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NPCCar extends Actor
{
    static int npcSpeed = 2;
    
    static int[][] path = {
        {450, 550},
        {440, 448},
        {249, 440},
        {249, 247},
        {434, 240},
        {456, 150},
        {550, 155},
        {537, 345},
        {152, 338},
        {150, 44},
        {356, 51},
        {336, 141},
        {46, 155},
        {46, 564},
        {292, 549},
    };
    
    int currentPoint = 0;
    
    public void Pathfinder(){
        int targetX = path[currentPoint][0];
        int targetY = path[currentPoint][1];
        
        turnTowards(targetX, targetY);
        move(npcSpeed);
    
        if (Math.abs(getX() - targetX) < 10 && Math.abs(getY() - targetY) < 10) {
        currentPoint++;
        if (currentPoint >= path.length) {
            currentPoint = 0;
        }
    }
}
public void act()
    {
        GreenfootImage img = getImage();
       img.scale(15, 20);
       sleepFor(0);
       Pathfinder();
    }
}
